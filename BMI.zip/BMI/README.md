# BMI Calculator

Click [here](https://willdowglas.github.io/html-css-js/BMI/) to view.
